package com.bysj.qiu.dao;

import com.bysj.qiu.pojo.Clothes;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;


@Mapper
public interface TestEachartsDao {

    List<Clothes> selTesteaCharts();

}
