package com.bysj.qiu.service;

import com.bysj.qiu.pojo.Clothes;

import java.util.List;

public interface TestService {

    List<Clothes> selTesteaCharts();
}
