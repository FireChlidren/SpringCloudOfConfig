package com.bysj.qiu.controller;


import com.bysj.qiu.pojo.Clothes;
import com.bysj.qiu.service.TestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;
@RequestMapping(value = "/other",method = RequestMethod.GET)
@Controller
public class TestController {


    @Autowired
    TestService eachartsService;
    @ResponseBody
    @GetMapping("/test")
    public List<Clothes> setTest(){
        List<Clothes> clothes = eachartsService.selTesteaCharts();
        return clothes;
    }


    @RequestMapping("/getname")
@ResponseBody
    public String wellcome(Model model)
    {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String name = auth.getName();
       model.addAttribute("role",name);
//        System.out.println(name);
//        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
//        System.out.println("unkunow"+authentication);
//        String s = authentication.getAuthorities().toString();
//        System.out.println(authentication.getAuthorities().toString());
        return name;
    }
    @RequestMapping("/hello")
    public String setTest2(){
        return "hello";
    }

}
