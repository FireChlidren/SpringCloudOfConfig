package com.bysj.qiu.service.serviceimpl;

import com.bysj.qiu.dao.AdminManagerPower;
import com.bysj.qiu.pojo.Secret;
import com.bysj.qiu.service.AdminManagerPowerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AdminManagerPowerImpl implements AdminManagerPowerService {
        @Autowired
        AdminManagerPower adminManagerPower;
//寻找到所有admin
        @Override
        public List<Secret> selthisAdminInfo() {
            return adminManagerPower.selthisAdminInfo();
        }
//更新admin信息
        @Override
        public int updathisAdminInfo(int id, String password, String user) {
                return adminManagerPower.updathisAdminInfo(id, password, user);
        }
//增加admin用户
        @Override
        public int insertAdmin(String user, String password,String fatheruser) {
                return adminManagerPower.insertAdmin(user, password, fatheruser);
        }
//查询出普通用户加分页
        @Override
        public List<Secret> selOtherUser(int nowpage) {
                int thiscount=10;
                int first = (nowpage-1)*thiscount;
                List<Secret> secrets = adminManagerPower.selOtherUser(first, thiscount);
                return secrets;
        }
//总数
        @Override
        public Integer selOthercount() {
                Integer count = adminManagerPower.selOthercount();
                return count;
        }
//删除普通用户
        @Override
        public int delOtherUser(int id) {
                int delbyid = adminManagerPower.delOtherUser(id);
                return delbyid;
        }

        @Override
        public int delAdminUser(int id) {
                return adminManagerPower.delAdminUser(id);
        }

        @Override
        public int upOtherUser(int id, String user, String password) {
                int upother = adminManagerPower.upOtherUser(id, user, password);
                return upother;
        }
//更新admin用户的头像
        @Override
        public int upadminheadimg(String headimg, String user) {
                return adminManagerPower.upadminheadimg(headimg, user);
        }

        @Override
        public Secret seladminheadimg(String user) {
                return adminManagerPower.seladminheadimg(user);
        }


}
