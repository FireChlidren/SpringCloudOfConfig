package com.bysj.qiu.service.serviceimpl;


import com.bysj.qiu.dao.GetSecret;
import com.bysj.qiu.pojo.Secret;
import com.bysj.qiu.service.GetSecretService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;

@Service
public class GetSecretServiceImpl implements GetSecretService {

    @Autowired
    GetSecret getSecret;
    @Override
    public Secret selAdminPower(String user) {
        return getSecret.selAdminPower(user);
    }

    @Override
    public Secret selOtherUserPower(String user) {
        return getSecret.selOtherUserPower(user);
    }

    @Override
    public Secret booleanUserPower(String user, String password) {
        return getSecret.booleanUserPower(user,password);
    }

    @Override
    public Secret booleanAdminPower(String user, String password) {
        return getSecret.booleanAdminPower(user,password);
    }

    @Override
    @Transactional
    //事务管理，如果遇到异常，则不会保存数据，不然的话如果执行到操作代码，但是遇到错误了还是会保存数据的。
    public int regist(String user, String password) {
        if(getSecret.selOtherUserPower(user) !=null){
            throw new RuntimeException("已经存在用户名");
        }
        int regist = getSecret.regist(user, password);
        return regist;

    }


}
