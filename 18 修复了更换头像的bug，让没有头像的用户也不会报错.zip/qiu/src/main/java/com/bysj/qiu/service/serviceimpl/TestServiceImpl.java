package com.bysj.qiu.service.serviceimpl;


import com.bysj.qiu.dao.TestEachartsDao;
import com.bysj.qiu.pojo.Clothes;
import com.bysj.qiu.service.TestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TestServiceImpl implements TestService {


    @Autowired
    TestEachartsDao testEachartsDao;

    @Override
    public List<Clothes> selTesteaCharts() {
        return testEachartsDao.selTesteaCharts();
    }



}
