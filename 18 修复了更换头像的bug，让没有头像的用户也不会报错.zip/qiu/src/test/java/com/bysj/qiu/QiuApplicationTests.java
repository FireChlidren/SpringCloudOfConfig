package com.bysj.qiu;

import com.bysj.qiu.dao.AdminManagerPower;
import com.bysj.qiu.dao.GetSecret;
import com.bysj.qiu.pojo.Secret;
import com.bysj.qiu.service.AdminManagerPowerService;
import com.bysj.qiu.service.GetSecretService;
import com.bysj.qiu.service.serviceimpl.AdminManagerPowerImpl;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Resource;
import java.util.List;

@RunWith(SpringRunner.class)
@SpringBootTest
public class QiuApplicationTests {
    @Autowired
    GetSecretService getSecretService;
    @Autowired
    GetSecret getSecret;
    @Autowired
    AdminManagerPowerService adminManagerPowerService;
    @Autowired
    AdminManagerPower adminManagerPower;


    @Test
    public void contextLoads() {
        int i = adminManagerPower.upOtherUser(2, "666", "666");
        System.out.println(i);
    }



    @Test
    public  void  four(){
        String s = getSecretService.booleanUserPower("qiu", "123").getPower().toString();
        String s2 = getSecretService.booleanAdminPower("admin", "123").getPower().toString();
        if(!s.equals(null)){
            System.out.println(s+s2);
        }
    }

}
